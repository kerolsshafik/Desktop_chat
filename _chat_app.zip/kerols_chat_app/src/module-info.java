module kerols.chat.app {
    requires javafx.fxml;
    requires javafx.controls;
    requires java.logging;
    opens sample;
}